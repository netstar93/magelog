
# Installation
- Extract over your magento root directory.
- php bin/magento setup:upgrade
- php bin/magento setup:di:compile
- php bin/magento setup:static-content:deploy
- chmod 777 var pub -R 
- php bin/magento indexer:reindex


# Usage
