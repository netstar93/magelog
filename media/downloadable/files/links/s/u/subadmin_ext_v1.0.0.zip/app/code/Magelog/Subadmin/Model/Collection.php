<?php
namespace Magelog\Subadmin\Model;

class Collection extends \Magento\Customer\Model\ResourceModel\Grid\Collection
{
     protected function _beforeLoad()
    {
        parent::_renderFiltersBefore();
        $joinTable = $this->getTable('customer_entity');

        // $this->getSelect()->JoinLeft($joinTable.' as secondtable','main_table.entity_id = secondtable.entity_id', array('added_by'));
       // echo $this->getSelect(); exit;
       

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $authSession = $objectManager->create('Magento\Backend\Model\Auth\Session');
        $admin = $authSession ->getUser();
        $adminUserName = $admin->getUsername();
        $role_name =  $admin->getRole() ->getRoleName();

        if($role_name == 'seller'){
        parent::_beforeLoad();
        $this->addFieldToFilter('added_by',['eq'=>$adminUserName]);
        }
        
        return $this;
    }

}