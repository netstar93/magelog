<?php

namespace Magelog\Subadmin\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Customer\Api\CustomerRepositoryInterface;

class Customersave implements ObserverInterface
{
    /** @var CustomerRepositoryInterface */
    protected $customerRepository;

    /**
     * @param CustomerRepositoryInterface $customerRepository
     */
    public function __construct(
        CustomerRepositoryInterface $customerRepository
    ) {
        $this->customerRepository = $customerRepository;
    }

    /**
     * Manages redirect
     */
    public function execute(Observer $observer)
    {

         $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
         $authSession = $objectManager->create('Magento\Backend\Model\Auth\Session');
         $admin = $authSession ->getUser();
         $adminUserName = $admin->getUsername();
         $role_name =  $admin->getRole() ->getRoleName();

        $accountController = $observer->getAccountController();
        $customer = $observer->getCustomer();
        
          if($role_name == 'seller'){
               $customerData =  $objectManager ->create('\Magento\Customer\Model\Customer')->load($customer->getId());
               $customerData ->setAddedBy($adminUserName)->save();
           }

    }
}